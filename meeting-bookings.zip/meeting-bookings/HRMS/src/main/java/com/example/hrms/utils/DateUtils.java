package com.example.hrms.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {
    // Định dạng ngày tháng giờ
    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm";
    private static final ZoneId ZONE_ID = ZoneId.of("Asia/Ho_Chi_Minh"); // UTC+7

    // Phương thức trả về đối tượng DateTimeFormatter với định dạng đã định sẵn
    public static DateTimeFormatter getDateTimeFormatter() {
        return DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
    }

    // Phương thức chuyển đổi chuỗi thành LocalDateTime theo định dạng
    public static LocalDateTime parseDateTime(String dateTimeStr) {
        return LocalDateTime.parse(dateTimeStr, getDateTimeFormatter());
    }

    // Phương thức chuyển đổi LocalDateTime thành chuỗi theo định dạng
    public static String formatDateTime(LocalDateTime dateTime) {
        return dateTime.format(getDateTimeFormatter());
    }

    // Phương thức chuyển đổi chuỗi thành ZonedDateTime theo định dạng và múi giờ
    public static ZonedDateTime parseZonedDateTime(String dateTimeStr) {
        LocalDateTime localDateTime = parseDateTime(dateTimeStr);
        return localDateTime.atZone(ZONE_ID);
    }

    // Phương thức chuyển đổi ZonedDateTime thành chuỗi theo định dạng
    public static String formatZonedDateTime(ZonedDateTime dateTime) {
        return dateTime.format(getDateTimeFormatter());
    }
}

